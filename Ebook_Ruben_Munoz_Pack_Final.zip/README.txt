README
---------------------------------------
Este paquete contiene:

/ebook/
- Ebook_15_Claves_FPE_Ruben_Munoz.pdf
  Ebook en formato cuadrado optimizado para web y móviles.
  Incluye: logo (abajo-derecha), texto en blanco, licencia CC BY-NC-SA, índice clicable, marcadores,
  enlaces clicables y banner final de LinkedIn.

/mockup/
- mockup_frontal.png (1200 px) → Vista frontal del ebook.
- mockup_perspectiva.png (1200 px) → Vista en perspectiva 3/4.
- mockup_cuadrado.png (1080 px) → Versión cuadrada con rótulo “Ebook gratuito” y logo.
- mockup_horizontal_CTA.png (1200×628 px) → Horizontal con subtítulo y botón “Descargar ahora”.
- mockup_horizontal_sinCTA.png (1200×628 px) → Horizontal con subtítulo, sin CTA.
- miniatura_ebook.jpg (400×400 px) → Miniatura ligera para web, solo con título y logo.

Cómo subir el eBook a LinkedIn en formato carrusel:
1) Entra en LinkedIn y crea una nueva publicación.
2) Selecciona la opción "Documento".
3) Sube /ebook/Ebook_15_Claves_FPE_Ruben_Munoz.pdf (formato cuadrado y ligero).
4) Título del documento: "Ebook gratuito: 15 claves para transformar la FPE".
5) En el texto del post, invita a comentar y descargar. Puedes usar los mockups como imagen previa.

Cómo usarlo en tu web:
- Sube el PDF a /assets/ y enlázalo desde tu botón de descarga.
- Usa la miniatura_ebook.jpg como vista previa junto al enlace.

Licencia: CC BY-NC-SA 4.0
---------------------------------------
